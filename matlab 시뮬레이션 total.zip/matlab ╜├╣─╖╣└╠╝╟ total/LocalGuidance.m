%%%Local Guidance

Fs = r_max_Local*exp((-(psi-ERP42.actdf).^2)/(2*sigma_Local^2));