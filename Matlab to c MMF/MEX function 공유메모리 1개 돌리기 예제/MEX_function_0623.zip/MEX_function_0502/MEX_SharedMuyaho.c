#include "mex.h"
#include <stdio.h>
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <stdbool.h>
#include <string.h>
#include <conio.h>
#include <tchar.h>

typedef struct
{
	unsigned int index_data;
	double data_1;
	double data_2;
} TEST_DATA;

TEST_DATA* test_smdat;

unsigned int  index_imu = 0;
double        data_1 = 0.0;
double        data_2 = 0.0;

HANDLE hMemoryMap = NULL;
LPBYTE pMemoryMap = NULL; // LPBYTE는 unsigned char의 포인터형
//gps

TCHAR TEST_SM[] = TEXT("test data");

void MemOpen_1();
void MemWrite();
void MemClose();

void mexFunction(int nlhs, mxArray* plhs[],         // Output variables
	int nrhs, const mxArray* prhs[])
{
    double *output;
    plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
    output = mxGetPr(plhs[0]);
    
    output[0] = data_1;
    //MEX_SharedMuyaho
    
	MemOpen_1();
	MemWrite();
	//mexPrintf("%f\n",data_1);
    
	MemClose();
}

void MemOpen_1()
{
	hMemoryMap = OpenFileMapping(
		FILE_MAP_READ,	  // read/write access
		FALSE,	          // do not inherit the name
		TEST_SM);          // 공유 파일맵의 이름 - Uique 해야한다.


	if (!hMemoryMap) {
		_tprintf(TEXT("Could not open file mapping object (%d).\n"),
			GetLastError());
		return FALSE;
	}

	pMemoryMap = (BYTE*)MapViewOfFile(
		hMemoryMap,				// 파일맵의 핸들
		FILE_MAP_READ,    // 액세스 모드 - 현재는 쓰기
		0,						// 메모리 시작번지부터의 이격된 상위 32비트 
		0,						// 메모리 시작번지부터의 이격된 하위 32비트
		0);						// 사용할 메모리 블록의 크기 - 0이면 설정한 전체 메모리

	if (!pMemoryMap)
	{
		CloseHandle(hMemoryMap);
		printf("COULD NOT OPEN THE SHARED MEMORY\n");
		return FALSE;
	}
	//printf("TEST1 SHARED MEMORY IS CREATED\n");

	//TEST_DATA* 
	test_smdat = (TEST_DATA*)pMemoryMap;
}

void MemWrite()
{
	data_1 = test_smdat->data_1;
	
}

void MemClose() {
	UnmapViewOfFile(pMemoryMap);
	CloseHandle(hMemoryMap);
	return 0;
}

