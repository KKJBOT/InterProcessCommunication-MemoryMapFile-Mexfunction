clear all;clc;
%%
mex MEX_SharedMuyaho.c;
%%
SIM_TIME = struct('CNT', 1, ...
    'Current', 0, ...
    'Elapsed', 0, ...
    'Start', 0, ...
    'Final', 30, ...
    'TS', 0.05);

SIM_TIME.Start = CheckWindowsTime(0, 0)* 0.001;
SIM_Time.Elapsed = 0;
task1 = 0;
task2 = 0;


while(SIM_TIME.Elapsed < SIM_TIME.Final)
  task1 = CheckWindowsTime(0, 0) * 0.001;
  tasktime = task1 - task2;
  task2 = CheckWindowsTime(0, 0) * 0.001;
  Data_in = MEX_SharedMuyaho;
    
  SIM_TIME.Elapsed =  SIM_TIME.TS * SIM_TIME.CNT;
 
  figure(1);
  plot(SIM_TIME.Elapsed,Data_in,'*'); hold on;
  xlim([0,30]);
  ylim([-5.5,5.5]);
  drawnow limitrate;
  
    while(1) 
        SIM_TIME.Current = CheckWindowsTime(0, 0) * 0.001;
        
        if(SIM_TIME.Current - SIM_TIME.Start > SIM_TIME.TS * SIM_TIME.CNT)
          
            SIM_TIME.CNT    = SIM_TIME.CNT + 1 ;
            break ;
        end
    end
    
end